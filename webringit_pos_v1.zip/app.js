// Simple WeBrinGiT POS mock logic v1

const productData = {
  pites: [
    { name: "Πίτα γύρος χοιρινός", price: 4.20, stock: true },
    { name: "Πίτα γύρος κοτόπουλο", price: 4.50, stock: true },
    { name: "Πίτα γύρος mix", price: 4.80, stock: true },
    { name: "Πίτα μπιφτέκι", price: 4.30, stock: true },
    { name: "Πίτα κεμπάπ", price: 4.60, stock: false }
  ],
  psomaki: [
    { name: "Ψωμάκι γύρος χοιρινός", price: 4.20, stock: true },
    { name: "Ψωμάκι γύρος κοτόπουλο", price: 4.50, stock: true },
    { name: "Ψωμάκι mix", price: 4.70, stock: true }
  ],
  merides: [
    { name: "Μερίδα γύρος χοιρινός", price: 8.00, stock: true },
    { name: "Μερίδα γύρος κοτόπουλο", price: 8.50, stock: true }
  ],
  salates: [
    { name: "Χωριάτικη", price: 6.00, stock: true },
    { name: "Ανάμικτη", price: 5.50, stock: true }
  ],
  drinks: [
    { name: "Coca Cola 330ml", price: 1.50, stock: true },
    { name: "Νερό 0.5L", price: 0.50, stock: true },
    { name: "Μπύρα Amstel", price: 3.50, stock: true }
  ]
};

let currentCategory = "pites";
let selectedProduct = null;
let selectedModifiers = new Set();
let qty = 1;
let order = [];

const productsGrid = document.getElementById("productsGrid");
const catButtons = document.querySelectorAll(".cat-btn");
const bottomMode = document.getElementById("bottomMode");
const btnTakeaway = document.getElementById("btnTakeaway");
const btnDelivery = document.getElementById("btnDelivery");
const nameWrap = document.getElementById("fld_name_wrap");
const addrWrap = document.getElementById("fld_addr_wrap");
const freqWrap = document.getElementById("freq_wrap");

function renderProducts() {
  productsGrid.innerHTML = "";
  productData[currentCategory].forEach((p) => {
    const card = document.createElement("div");
    card.className = "product-card" + (p.stock ? "" : " out-of-stock");
    card.innerHTML = `
      <div class="product-name">${p.name}</div>
      <div class="product-footer">
        <span>${p.stock ? "Διαθέσιμο" : "Μη διαθέσιμο"}</span>
        <span class="product-price">${p.price.toFixed(2)}€</span>
      </div>
    `;
    card.onclick = () => {
      if (!p.stock) return;
      selectProduct(p);
    };
    card.oncontextmenu = (e) => {
      e.preventDefault();
      if (confirm("Να γίνει ΕΚΤΟΣ ΣΤΟΚ: " + p.name + " ;")) {
        p.stock = false;
        renderProducts();
      }
    };
    productsGrid.appendChild(card);
  });
}

function selectProduct(p) {
  selectedProduct = p;
  selectedModifiers.clear();
  qty = 1;
  document.getElementById("selName").textContent = p.name;
  document.getElementById("selPrice").textContent = p.price.toFixed(2) + "€";
  document.getElementById("qtyValue").textContent = qty;
  document.querySelectorAll(".mod-chip").forEach(ch => ch.classList.remove("selected"));
}

function updateTotals() {
  let total = order.reduce((sum, item) => sum + item.price * item.qty, 0);
  const txt = total.toFixed(2) + "€";
  document.getElementById("totalValueLeft").textContent = txt;
  document.getElementById("totalValueRight").textContent = txt;
}

function renderOrder() {
  const container = document.getElementById("orderList");
  container.innerHTML = "";
  order.forEach((item) => {
    const row = document.createElement("div");
    row.className = "order-item";
    row.innerHTML = `
      <div class="order-qty">${item.qty}×</div>
      <div class="order-name">${item.name}</div>
      <div class="order-price">${(item.price * item.qty).toFixed(2)}€</div>
      <div class="order-mods">
        ${
          item.modifiers.length
            ? item.modifiers.map(m => `<span>• ${m}</span>`).join("")
            : "<span>• Χωρίς αλλαγές</span>"
        }
      </div>
    `;
    container.appendChild(row);
  });
  updateTotals();
}

// Categories
catButtons.forEach(btn => {
  btn.addEventListener("click", () => {
    catButtons.forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    currentCategory = btn.getAttribute("data-cat");
    renderProducts();
  });
});

// Modifiers
document.querySelectorAll(".mod-chip").forEach(chip => {
  chip.addEventListener("click", () => {
    const val = chip.getAttribute("data-mod");
    if (chip.classList.contains("selected")) {
      chip.classList.remove("selected");
      selectedModifiers.delete(val);
    } else {
      chip.classList.add("selected");
      selectedModifiers.add(val);
    }
  });
});

// Quantity
document.getElementById("btnQtyMinus").onclick = () => {
  if (qty > 1) {
    qty--;
    document.getElementById("qtyValue").textContent = qty;
  }
};
document.getElementById("btnQtyPlus").onclick = () => {
  if (qty < 999) {
    qty++;
    document.getElementById("qtyValue").textContent = qty;
  }
};

// Add to order
document.getElementById("btnAdd").onclick = () => {
  if (!selectedProduct) {
    alert("Επίλεξε πρώτα προϊόν.");
    return;
  }
  const mods = Array.from(selectedModifiers);
  order.push({
    name: selectedProduct.name,
    price: selectedProduct.price,
    modifiers: mods,
    qty
  });
  renderOrder();
};

// Frequent products
document.querySelectorAll(".freq-pill").forEach(btn => {
  btn.addEventListener("click", () => {
    const name = btn.getAttribute("data-name");
    const price = parseFloat(btn.getAttribute("data-price"));
    selectedProduct = { name, price, stock: true };
    selectedModifiers.clear();
    qty = 1;
    document.getElementById("selName").textContent = name;
    document.getElementById("selPrice").textContent = price.toFixed(2) + "€";
    document.getElementById("qtyValue").textContent = qty;
    document.querySelectorAll(".mod-chip").forEach(ch => ch.classList.remove("selected"));
    order.push({ name, price, modifiers: [], qty: 1 });
    renderOrder();
  });
});

// Mode toggle
function setMode(mode) {
  if (mode === "TAKEAWAY") {
    btnTakeaway.classList.add("active");
    btnDelivery.classList.remove("active");
    bottomMode.textContent = "ΠΑΚΕΤΟ";
    nameWrap.style.display = "none";
    addrWrap.style.display = "none";
    freqWrap.style.display = "none"; // συχνά προϊόντα μόνο στη διανομή
  } else {
    btnDelivery.classList.add("active");
    btnTakeaway.classList.remove("active");
    bottomMode.textContent = "ΔΙΑΝΟΜΗ";
    nameWrap.style.display = "block";
    addrWrap.style.display = "block";
    freqWrap.style.display = "block";
  }
}

btnTakeaway.onclick = () => setMode("TAKEAWAY");
btnDelivery.onclick = () => setMode("DELIVERY");

// Cancel & send
document.getElementById("btnCancel").onclick = () => {
  if (confirm("Να ακυρωθεί πλήρως η παραγγελία;")) {
    order = [];
    renderOrder();
    document.getElementById("orderNotes").value = "";
  }
};

document.getElementById("btnSend").onclick = () => {
  const summary = {
    mode: bottomMode.textContent,
    phone: document.getElementById("fld_phone").value,
    name: document.getElementById("fld_name").value,
    address: document.getElementById("fld_address").value,
    total: document.getElementById("totalValueLeft").textContent,
    notes: document.getElementById("orderNotes").value,
    items: order
  };
  alert("DEMO – Αποστολή στην κουζίνα:\n" + JSON.stringify(summary, null, 2));
};

document.getElementById("btnBack").onclick = () => {
  alert("DEMO – Επιστροφή (δεν κάνει κάτι τώρα).");
};

// Init
renderProducts();
setMode("TAKEAWAY");
renderOrder();
